ceilometer data collection



